# AI Training Oefening: Few-Shot Prompting in de Bouwsector

## 1. Techniek: Few-Shot Prompting

**Few-shot prompting** betekent dat je 2-3 voorbeelden meegeeft waardoor het AI-model het patroon leert herkennen. Dit werkt beter dan enkel beschrijven wat je wilt, vooral voor taken met impliciete stijlregels of complexe patronen.

## 2. Casus

Een bouwbedrijf in Vlaanderen moet dagelijks **dagrapportages** maken voor verschillende werven. Deze rapporten moeten een specifieke structuur, toon en detailniveau hebben die moeilijk te beschrijven is, maar wel duidelijk herkenbaar is voor wie er enkele ziet. De opdracht: leer het model de juiste stijl aan door voorbeelden te geven.

## 3. Waarom een gewone prompt faalt

1. **Impliciete stijlregels** - Het is moeilijk om in woorden uit te leggen hoe technisch, bondig en praktijkgericht de toon moet zijn
2. **Structuurdetails** - Welke velden precies, in welke volgorde, en hoe uitgebreid blijft abstract zonder voorbeelden
3. **Belgische context** - Typische woordkeuze ("werf", "ploegbaas", "beton storten") en afkortingen zijn moeilijk te specificeren
4. **Detailniveau** - Hoeveel detail bij obstakels en oplossingen? Te weinig instructie leidt tot te uitgebreide of te korte rapporten

## 4. Training Assets

### Asset 1: Eerste voorbeelddagrapport

```text
# dagrapport_voorbeeld_1.txt

DAGRAPPORT WERF GENT - RESIDENTIE ARTEVELDE

Datum: 15 maart 2024
Werf: W-2024-087
Ploegbaas: Janssens Marc
Weer: bewolkt, droog, 8°C

UITGEVOERDE WERKEN:
- Bekisting afgewerkt parking kelder (-1)
- Wapening geplaatst kolommen as B t/m D
- Betonleverancier gebeld: levering zaterdag 08:00u bevestigd (18m³ C30/37)

AANWEZIGE PLOEG:
- 2 timmermannen (bekisting)
- 3 ijzervlechters (wapening)
- 1 polyvalente arbeider (ondersteuning)

MATERIAAL GELEVERD:
- Betonijzer Ø16mm: 850kg (Vandenborre Staal)
- Multiplex bekistingsplaten: 45 stuks (Houthandel Merelbeke)

PROBLEMEN/OPMERKINGEN:
- Kraanwagen komt pas maandag ipv vrijdag door pech, alternatieven bekeken
- Inspectie betonwapening gepland dinsdag 9u (controleur Vinçotte)

PLANNING MORGEN:
- Bekisting afsluiten en controleren
- Start voorbereiding storten vloerplaat
```

### Asset 2: Tweede voorbeelddagrapport

```text
# dagrapport_voorbeeld_2.txt

DAGRAPPORT WERF ANTWERPEN - KANTOORGEBOUW BERCHEM

Datum: 22 maart 2024
Werf: W-2024-103
Ploegbaas: De Vries Peter
Weer: regen in voormiddag, 11°C

UITGEVOERDE WERKEN:
- Gevelbekleding verdieping 3 geplaatst (gevel noord en oost)
- Leidingwerk sanitair afgewerkt niveau 2
- Isolatie dak aangebracht zone A (800m²)

AANWEZIGE PLOEG:
- 4 gevelwerkers (prefab panelen)
- 2 loodgieters (sanitair)
- 2 dakwerkers (isolatie)

MATERIAAL GELEVERD:
- Gevelpanelen: 18 stuks (Prelco Systems)
- PVC riolering 110mm: 85 meter (Van Marcke)
- PIR isolatieplaten 120mm: 65m² (Recticel)

PROBLEMEN/OPMERKINGEN:
- Werk buitengevel stilgelegd 10u-13u wegens regen
- 3 gevelpanelen lichte beschadiging transport, leverancier gecontacteerd voor vervanging
- Onderaannemer elektriciteit morgen één dag later (ziekte)

PLANNING MORGEN:
- Voortzetten gevelbekleding west- en zuidgevel
- Start tegelwerk sanitair verdieping 1
```

### Asset 3: Nieuwe context voor generatie

```text
# dagrapport_input_nieuw.txt

Maak een dagrapport op basis van volgende informatie:

Datum: 4 april 2024
Werf: Nieuwbouw school Mechelen (W-2024-121)
Ploegbaas: Van Dijck Tom
Weer: zonnig, 15°C

Wat er gebeurd is:
- Funderingswerken afgerond zone sporthal
- Drainage aangelegd rondom funderingen
- Grondwerker heeft nivellering parking gedaan
- Er zijn 12 betonpalen geleverd door Franki
- Morgen komt betoncentrale voor fundering sporthal (32m³)
- Kraanmachinist was ziek dus onderdeel van takeling uitgesteld
- Inspectie funderingen gepland voor overmorgen door BTV
- Aanwezig: 3 grondwerkers, 2 timmermannen, 1 kraanmachinist (halve dag)

Gevraagde extra materiaal voor volgende week: betonstaal Ø20mm (1200kg) en drainage grintkoffers (15m³)
```

## 5. Baseline Prompt (ZONDER Few-Shot)

```text
Maak een professioneel dagrapport voor een bouwwerf op basis van de informatie in dagrapport_input_nieuw.txt. 

Het rapport moet de juiste structuur hebben voor een Belgisch bouwbedrijf en informatie bevatten over uitgevoerde werken, personeel, materiaal, problemen en planning.
```

**Verwacht resultaat baseline**: Het model maakt waarschijnlijk een rapport dat:
- Te formeel of juist te informeel is
- Inconsistente structuur heeft (andere velden dan de voorbeelden)
- Te weinig of te veel detail bevat
- Niet de typische Belgische bouwterminologie gebruikt

## 6. Prompt MET Few-Shot Techniek

```text
Ik geef je twee voorbeelden van dagrapportages zoals wij die op de werf gebruiken. Bestudeer de structuur, stijl, toon en het detailniveau.

VOORBEELD 1:
[plak hier volledige inhoud van dagrapport_voorbeeld_1.txt]

VOORBEELD 2:
[plak hier volledige inhoud van dagrapport_voorbeeld_2.txt]

Maak nu een nieuw dagrapport in exact dezelfde stijl en structuur op basis van deze informatie:
[plak hier volledige inhoud van dagrapport_input_nieuw.txt]

Volg het patroon van de voorbeelden: zelfde secties, vergelijkbare zinsbouw, praktijkgerichte toon, Belgische terminologie.
```

## 7. Expected Output (met Few-Shot)

```text
DAGRAPPORT WERF MECHELEN - NIEUWBOUW SCHOOL

Datum: 4 april 2024
Werf: W-2024-121
Ploegbaas: Van Dijck Tom
Weer: zonnig, 15°C

UITGEVOERDE WERKEN:
- Funderingswerken afgerond zone sporthal
- Drainage aangelegd rondom funderingen
- Nivellering parking uitgevoerd door grondwerker
- Betoncentrale bevestigd voor morgen 08:00u (32m³ fundering sporthal)

AANWEZIGE PLOEG:
- 3 grondwerkers (fundering en drainage)
- 2 timmermannen (bekisting)
- 1 kraanmachinist (halve dag, daarna ziek uitgevallen)

MATERIAAL GELEVERD:
- Betonpalen: 12 stuks (Franki)

PROBLEMEN/OPMERKINGEN:
- Kraanmachinist ziek na middag, takeling uitgesteld naar volgende week
- Inspectie funderingen gepland zaterdag (controleur BTV)
- Materiaalbestelling volgende week: betonstaal Ø20mm (1200kg) + drainage grintkoffers (15m³)

PLANNING MORGEN:
- Storten funderingen sporthal (32m³ vanaf 08:00u)
- Bekisting voorbereiden voor volgende fase
```

**Opmerking**: Het model heeft nu automatisch:
- Dezelfde secties gebruikt (hoofdletters, dubbele punt)
- Bondig en praktijkgericht geformuleerd
- Belgische terminologie ("werf", "ploegbaas", "storten")
- Vergelijkbaar detailniveau aangehouden
- Logische volgorde toegepast

## 8. Meerwaarde van Few-Shot in deze context

1. **Impliciete stijlregels worden overgenomen** - Het model leert de toon ("bekisting voorbereiden", "afgerond", "uitgevallen") zonder dat je dit moet uitleggen
2. **Structuurconsistentie** - Alle secties komen terug in dezelfde volgorde en met dezelfde opmaak, wat zorgt voor herkenbaarheid
3. **Detailniveau automatisch correct** - Het model ziet in de voorbeelden hoeveel detail nodig is bij problemen en materiaal
4. **Belgische context herkenbaar** - Typische woorden ("werf", "ploegbaas", "storten beton") en referenties (Franki, BTV, Vinçotte) worden correct gebruikt
5. **Minder iteraties nodig** - Waar je zonder voorbeelden 3-4 keer moet verfijnen, krijg je nu vaak direct een bruikbaar rapport

## 9. Variant / Transferoefening

**Alternatieve opdracht**: Pas dezelfde few-shot techniek toe voor:

- **Interventierapportages** bij installateurs (HVAC, elektriciteit)
- **Werfvergaderingen notulen** met beslissingspunten en actiepunten
- **Leveringsbonnen omzetten** naar gestructureerde bestelformulieren
- **Nacalculatie rapporten** voor afgeronde projecten

**Concreet voorbeeld**: Geef 2 voorbeelden van interventierapportages voor een verwarmingsinstallateur, laat het model een derde genereren op basis van losse notities ("klant had geen warm water, circulatiepomp defect, vervangen, getest").

## 10. De oefening is geslaagd als...

1. ✅ Het gegenereerde rapport heeft **exact dezelfde secties** als de voorbeelden (geen extra, geen ontbrekende velden)
2. ✅ De **toon is praktijkgericht en bondig**, vergelijkbaar met de voorbeeldstijl (geen lange zinnen, geen overdreven formeel taalgebruik)
3. ✅ **Belgische bouwterminologie** wordt correct gebruikt (werf, ploegbaas, storten, bekisting, enz.)
4. ✅ Het **detailniveau** bij problemen en planning komt overeen met de voorbeelden (niet te summier, niet te uitgebreid)
5. ✅ De cursist begrijpt dat **few-shot beter werkt dan uitleggen** voor taken met impliciete stijlregels

## 11. Trainer Notes

**Geschatte duur**: 20-25 minuten
- 5 min: Uitleg few-shot principe
- 5 min: Cursisten lezen voorbeelden door
- 10 min: Cursisten voeren oefening uit (baseline + few-shot)
- 5 min: Vergelijken resultaten en discussie

**Valkuilen**:
- Cursisten vergeten beide voorbeelden volledig te kopiëren in de prompt
- Cursisten denken dat 1 voorbeeld genoeg is (leg uit waarom 2-3 optimaal is)
- Voorbeelden zijn te verschillend waardoor patroon onduidelijk wordt
- Nieuw scenario is te afwijkend van voorbeelden (kies vergelijkbare context)

**Geschikte tools**:
- ✅ Claude (excellent, begrijpt subtiele patronen)
- ✅ ChatGPT (goed, vooral GPT-4)
- ✅ Gemini (goed bruikbaar)

**Demowaarde** (live tonen in 3 minuten):
1. Toon eerst resultaat van baseline prompt → onvoldoende consistent
2. Toon dan resultaat met twee voorbeelden erbij → direct correcte stijl
3. Highlight concreet verschil: consistentie in secties, terminologie, toon
4. Laat zien dat je voorbeelden herbruikbaar zijn voor alle toekomstige dagrapportages

**Pro-tip voor trainer**: 
Maak samen met cursisten een "voorbeeldenbibliotheek" aan met 2-3 goede voorbeelden per documenttype. Deze kunnen ze dan steeds hergebruiken in hun prompts. Dit verhoogt de praktische toepasbaarheid enorm.

---

## Bonus: Uitbreidingsmogelijkheden

**Voor gevorderde cursisten**:
- Combineer few-shot met **CRISPE** (geef voorbeelden + expliciete rol/stijlrichtlijnen)
- Gebruik few-shot voor **complexere taken** zoals veiligheidsanalyses of nacalculaties
- Experimenteer met **aantal voorbeelden** (2 vs 3 vs 4) en meet kwaliteitsverschil
- Pas toe op **meertalige context** (NL/FR rapporten in Brussel)

**Variatie in moeilijkheidsgraad**:
- **Basic**: Dagrapportages (zoals deze oefening)
- **Medium**: Inspectierapporten met afwijkingen en aanbevelingen
- **Advanced**: Complete projectdocumentatie met meerdere secties en technische specificaties
