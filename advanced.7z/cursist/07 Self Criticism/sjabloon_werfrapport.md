# WERFRAPPORT - [PROJECTNAAM]

**Werf:** [Naam werf]
**Werfnummer:** [Nummer]
**Rapportageperiode:** Week [XX] ([datums])
**Opgesteld door:** [Naam], Projectleider
**Datum rapport:** [datum]

---

## 1. SAMENVATTING

[2-3 zinnen: algemene status werf, belangrijkste berichten]

---

## 2. VOORTGANG WERKZAAMHEDEN

### Uitgevoerde werkzaamheden
- [Concrete activiteiten met percentage voortgang]
- [Status per werkzone indien van toepassing]

### Planning status
- **Op schema** / **Vertraging** / **Voorsprong**: [Aantal dagen] 
- **Reden**: [Korte toelichting]

---

## 3. MATERIAAL & LEVERINGEN

### Ontvangen leveringen
- [Materiaal + leverancier + datum]

### Problemen/afwijkingen
- [Beschrijf eventuele problemen met leveringen]

### Openstaande bestellingen
- [Verwachte leveringen komende week]

---

## 4. PERSONEEL & ONDERAANNEMERS

- Eigen personeel: [X] personen gemiddeld
- Onderaannemers aanwezig: [Lijst]
- Afwezigheden/issues: [Indien relevant]

---

## 5. KWALITEIT & VEILIGHEID

### Kwaliteitscontroles
- [Uitgevoerde controles, wachtend op controles]

### Veiligheid
- Incidenten: [Aantal, beschrijving]
- Maatregelen: [Indien nodig]

---

## 6. RISICO'S & AANDACHTSPUNTEN

- [Actuele risico's voor planning/kwaliteit]
- [Acties om risico's te beperken]

---

## 7. PLANNING KOMENDE WEEK

- [Geplande activiteiten week X]
- [Kritieke paden / afhankelijkheden]

---

## 8. BESLISSINGEN & ACTIEPUNTEN

| Actie | Verantwoordelijke | Deadline |
|-------|------------------|----------|
| [Actie 1] | [Persoon/bedrijf] | [Datum] |
| [Actie 2] | [Persoon/bedrijf] | [Datum] |

---

**Opmerking**: Dit rapport is opgesteld conform de rapportageverplichting zoals overeengekomen in het bestek.
