# Trainingsoefening: Self Criticism & Revision Loops Prompting
## Techniek: Zelfkritiek + Revisie voor de Bouwsector

---

## 1. Techniek: Zelfkritiek + Revisie

**Self Criticism & Revision Loops** is een prompt-techniek waarbij je de AI in drie fases laat werken:

1. **Genereren** - Maak een eerste versie van het document
2. **Evalueren** - Beoordeel de kwaliteit tegen concrete criteria
3. **Verbeteren** - Herschrijf op basis van de zelfkritiek

Deze techniek zorgt voor betere kwaliteit omdat de AI expliciet zichzelf controleert en verbetert, net zoals een ervige projectleider een rapport checkt voordat het naar de klant gaat.

---

## 2. Casus: Wekelijkse Werfrapportage

Je bent projectleider bij aannemingsbedrijf **Verstraete Bouw NV** in Gent. Elke week moet je een gestructureerde werfrapportage sturen naar de opdrachtgever (AG Real Estate). Deze rapportage moet voldoen aan een strikt sjabloon en professionele taal gebruiken. Je hebt deze week ruwe notities van de werfleider ontvangen die je moet omzetten naar een volwaardig rapport.

---

## 3. Waarom een gewone prompt faalt

Een baseline prompt zoals *"Maak een werfrapport van deze notities"* schiet tekort omdat:

1. **Geen kwaliteitscontrole** - De AI genereert een rapport zonder te checken of het voldoet aan de vereiste structuur en professionele normen
2. **Incomplete secties** - Belangrijke onderdelen zoals risico's of vervolgacties kunnen ontbreken of oppervlakkig behandeld worden
3. **Inconsistente toon** - Het rapport kan te informeel blijven ("alles loopt goed") in plaats van professioneel en zakelijk
4. **Geen verificatie** - Informatie uit de notities wordt niet gecontroleerd op volledigheid (bijv. zijn alle leveringsproblemen vermeld?)

---

## 4. Training Assets

### Asset 1: Ruwe notities van werfleider

```text
# notities_werf_23oktober.txt

Werf: Residentie Zonnepark - Merelbeke
Werfnummer: MB-2024-087
Datum: week 43 (23-27 oktober 2025)

Voortgang:
- Fundering zone A klaar gegoten vrijdag
- Wachten op kwaliteitscontrole betonleverancier (Holcim)
- Rioleringswerken gestart dinsdag, 60% klaar
- Elektricien nog niet langs geweest voor leidingen kelder

Materiaal:
- Bestelling staalvlechtwerk te laat (zou maandag komen, geleverd woensdag)
- Isolatieplaten OK geleverd
- Probleem met verkeerde buizen voor riolering (diameter 200 ipv 250) - retour gestuurd

Personeel:
- Team 8 man deze week
- 2 man ziek donderdag en vrijdag
- Onderaannemer Elektro Van Damme had geen mankracht

Planning:
- Achterstand van 3 dagen door late staallevering
- Kunnen inhalen volgende week als elektricien komt
- Weer was goed, geen vertraging

Veiligheid:
- Geen ongevallen
- 1 waarschuwing gegeven voor ontbrekende helm bezoeker

Overleg:
- Dinsdag bouwvergadering met architect Callebaut
- Besproken: aanpassing raamkozijnen verdieping 2
```

### Asset 2: Sjabloon Werfrapportage

```markdown
# sjabloon_werfrapport.md

# WERFRAPPORT - [PROJECTNAAM]

**Werf:** [Naam werf]
**Werfnummer:** [Nummer]
**Rapportageperiode:** Week [XX] ([datums])
**Opgesteld door:** [Naam], Projectleider
**Datum rapport:** [datum]

---

## 1. SAMENVATTING

[2-3 zinnen: algemene status werf, belangrijkste berichten]

---

## 2. VOORTGANG WERKZAAMHEDEN

### Uitgevoerde werkzaamheden
- [Concrete activiteiten met percentage voortgang]
- [Status per werkzone indien van toepassing]

### Planning status
- **Op schema** / **Vertraging** / **Voorsprong**: [Aantal dagen] 
- **Reden**: [Korte toelichting]

---

## 3. MATERIAAL & LEVERINGEN

### Ontvangen leveringen
- [Materiaal + leverancier + datum]

### Problemen/afwijkingen
- [Beschrijf eventuele problemen met leveringen]

### Openstaande bestellingen
- [Verwachte leveringen komende week]

---

## 4. PERSONEEL & ONDERAANNEMERS

- Eigen personeel: [X] personen gemiddeld
- Onderaannemers aanwezig: [Lijst]
- Afwezigheden/issues: [Indien relevant]

---

## 5. KWALITEIT & VEILIGHEID

### Kwaliteitscontroles
- [Uitgevoerde controles, wachtend op controles]

### Veiligheid
- Incidenten: [Aantal, beschrijving]
- Maatregelen: [Indien nodig]

---

## 6. RISICO'S & AANDACHTSPUNTEN

- [Actuele risico's voor planning/kwaliteit]
- [Acties om risico's te beperken]

---

## 7. PLANNING KOMENDE WEEK

- [Geplande activiteiten week X]
- [Kritieke paden / afhankelijkheden]

---

## 8. BESLISSINGEN & ACTIEPUNTEN

| Actie | Verantwoordelijke | Deadline |
|-------|------------------|----------|
| [Actie 1] | [Persoon/bedrijf] | [Datum] |
| [Actie 2] | [Persoon/bedrijf] | [Datum] |

---

**Opmerking**: Dit rapport is opgesteld conform de rapportageverplichting zoals overeengekomen in het bestek.
```

---

## 5. Baseline Prompt (zonder techniek)

```text
Maak een professioneel werfrapport op basis van deze notities van de werfleider.

[notities_werf_23oktober.txt]

Gebruik dit sjabloon:

[sjabloon_werfrapport.md]
```

**Probleem**: Deze prompt genereert direct een rapport zonder zelfcontrole. Het resultaat zal:
- Mogelijk incomplete secties bevatten
- Niet alle risico's correct identificeren
- Geen verificatie doen of het sjabloon volledig gevolgd werd

---

## 6. Prompt met Self Criticism & Revision Loops

```text
Ik wil dat je een professioneel werfrapport opstelt, maar werk in drie fases:

**FASE 1 - GENEREER EERSTE VERSIE**
Maak een eerste versie van het werfrapport op basis van de notities van de werfleider.

Bronmateriaal (notities):
[notities_werf_23oktober.txt]

Te gebruiken sjabloon:
[sjabloon_werfrapport.md]

---

**FASE 2 - ZELFEVALUATIE**
Beoordeel je eigen eerste versie kritisch aan de hand van deze checklist:

STRUCTUUR:
□ Zijn alle 8 secties van het sjabloon aanwezig?
□ Is de volgorde correct?
□ Zijn alle tabellen/lijsten correct opgemaakt?

VOLLEDIGHEID:
□ Zijn alle problemen uit de notities opgenomen (late levering, ziekte, verkeerde materiaal)?
□ Zijn concrete cijfers gebruikt (percentage, aantal dagen, aantallen)?
□ Is de planning-impact duidelijk benoemd?

PROFESSIONALITEIT:
□ Is de toon zakelijk en objectief?
□ Zijn alle bedrijfsnamen en data correct?
□ Zijn er vage formuleringen ("alles loopt goed") vermeden?

RISICO-IDENTIFICATIE:
□ Zijn alle risico's voor de planning geïdentificeerd?
□ Zijn afhankelijkheden tussen problemen benoemd?
□ Zijn concrete mitigerende acties voorgesteld?

Schrijf je bevindingen op in 4-5 punten: wat ontbreekt of kan beter?

---

**FASE 3 - REVISIE**
Herschrijf het rapport volledig op basis van je zelfevaluatie. Los alle geïdentificeerde tekortkomingen op.

Lever het definitieve rapport op dat klaar is om naar de opdrachtgever te sturen.
```

---

## 7. Expected Output (wat de AI moet genereren)

```text
=== FASE 1: EERSTE VERSIE ===

# WERFRAPPORT - RESIDENTIE ZONNEPARK

**Werf:** Residentie Zonnepark - Merelbeke
**Werfnummer:** MB-2024-087
**Rapportageperiode:** Week 43 (23-27 oktober 2025)
**Opgesteld door:** [Naam], Projectleider
**Datum rapport:** 30 oktober 2025

---

## 1. SAMENVATTING

Deze week zijn de funderingswerkzaamheden in zone A afgerond en zijn de rioleringswerken gestart. Er is een vertraging van 3 dagen ontstaan door late levering van staalvlechtwerk. De situatie is beheersbaar mits de elektricien volgende week beschikbaar is.

## 2. VOORTGANG WERKZAAMHEDEN

### Uitgevoerde werkzaamheden
- Fundering zone A: 100% (gegoten vrijdag 27 oktober)
- Rioleringswerken: 60% (gestart dinsdag)
- Wachtend op kwaliteitscontrole betonleverancier Holcim

### Planning status
- **Vertraging**: 3 dagen
- **Reden**: Late levering staalvlechtwerk (gepland maandag, geleverd woensdag)

## 3. MATERIAAL & LEVERINGEN

### Ontvangen leveringen
- Isolatieplaten conform planning
- Staalvlechtwerk (2 dagen vertraagd)

### Problemen/afwijkingen
- Verkeerde rioleringsbuizen geleverd (diameter 200 in plaats van 250) - geretourneerd

### Openstaande bestellingen
- Vervangende rioleringsbuizen (diameter 250)

## 4. PERSONEEL & ONDERAANNEMERS

- Eigen personeel: 8 personen
- Afwezigheden: 2 personen ziek (donderdag en vrijdag)
- Onderaannemer Elektro Van Damme: niet verschenen (mankrachtprobleem)

## 5. KWALITEIT & VEILIGHEID

### Kwaliteitscontroles
- Wachtend op controle betonleverancier Holcim voor fundering zone A

### Veiligheid
- Incidenten: 0
- Waarschuwing gegeven: 1 bezoeker zonder helm

## 6. RISICO'S & AANDACHTSPUNTEN

- Elektricien nog niet langs geweest voor kelderinstallaties
- Afhankelijkheid van beschikbaarheid Elektro Van Damme volgende week

## 7. PLANNING KOMENDE WEEK

- Afwerking rioleringswerken
- Elektricien voor kelderleidingen
- Kwaliteitscontrole betonwerk

## 8. BESLISSINGEN & ACTIEPUNTEN

| Actie | Verantwoordelijke | Deadline |
|-------|------------------|----------|
| Kelderinstallaties plaatsen | Elektro Van Damme | 3 november 2025 |
| Nieuwe rioleringsbuizen leveren | Leverancier | 30 oktober 2025 |

---

**Opmerking**: Dit rapport is opgesteld conform de rapportageverplichting zoals overeengekomen in het bestek.

=== FASE 2: ZELFEVALUATIE ===

Laat me mijn eerste versie kritisch beoordelen:

1. **Onvolledige risico-analyse**: Ik heb niet expliciet gemaakt dat de 3-dagen vertraging alleen kan worden ingehaald als de elektricien daadwerkelijk komt. De afhankelijkeidsketen elektricien→inhalen planning is cruciaal maar niet duidelijk benoemd.

2. **Onduidelijke impact verkeerde buizen**: Ik vermeld dat verkeerde rioleringsbuizen zijn geretourneerd, maar niet of dit een planningsimpact heeft. Dit is een gemiste kans om volledig te zijn.

3. **Vage formulering samenvatting**: "De situatie is beheersbaar mits..." is te vrijblijvend voor een professioneel rapport. Ik moet concreter zijn over voorwaarden.

4. **Ontbrekende actie architect**: In de notities staat dat er dinsdag overleg was met architect Callebaut over aanpassing raamkozijnen verdieping 2. Dit is nergens in het rapport opgenomen, terwijl het relevant kan zijn.

5. **Geen escalatie-opties**: Bij de risico's ontbreekt wat er gebeurt als Elektro Van Damme volgende week weer niet komt. Er is geen plan B.

=== FASE 3: DEFINITIEVE VERSIE ===

# WERFRAPPORT - RESIDENTIE ZONNEPARK

**Werf:** Residentie Zonnepark - Merelbeke
**Werfnummer:** MB-2024-087
**Rapportageperiode:** Week 43 (23-27 oktober 2025)
**Opgesteld door:** [Naam], Projectleider
**Datum rapport:** 30 oktober 2025

---

## 1. SAMENVATTING

Deze week zijn de funderingswerkzaamheden in zone A voltooid en zijn de rioleringswerken voor 60% uitgevoerd. Er is een vertraging van 3 dagen ontstaan door late levering van staalvlechtwerk. Deze vertraging kan worden ingehaald in week 44, op voorwaarde dat onderaannemer Elektro Van Damme beschikbaar is voor de kelderinstallaties. Dit vormt momenteel het grootste risico voor de planning.

---

## 2. VOORTGANG WERKZAAMHEDEN

### Uitgevoerde werkzaamheden
- Fundering zone A: 100% (gegoten vrijdag 27 oktober, wachtend op kwaliteitscontrole Holcim)
- Rioleringswerken: 60% (gestart dinsdag 24 oktober)
- Bouwvergadering afgewerkt: aanpassing raamkozijnen verdieping 2 besproken met architect Callebaut

### Planning status
- **Vertraging**: 3 dagen (actuele stand 27 oktober)
- **Reden**: Staalvlechtwerk geleverd op woensdag 25 oktober in plaats van maandag 23 oktober
- **Inhaalplan**: Vertraging kan worden gecompenseerd in week 44 als elektricien tijdig werkt

---

## 3. MATERIAAL & LEVERINGEN

### Ontvangen leveringen
- Isolatieplaten conform planning
- Staalvlechtwerk (2 dagen vertraagd, ontvangen 25 oktober)

### Problemen/afwijkingen
- Rioleringsbuizen met verkeerde diameter geleverd (200mm in plaats van 250mm conform bestek)
- Materiaal geretourneerd op 26 oktober
- Vervangende levering verwacht 30 oktober - geen planningsimpact verwacht

### Openstaande bestellingen
- Vervangende rioleringsbuizen diameter 250mm (kritiek voor afwerking rioleringswerken)

---

## 4. PERSONEEL & ONDERAANNEMERS

- Eigen personeel: 8 personen gemiddeld
- Afwezigheden: 2 personen ziek op donderdag 26 en vrijdag 27 oktober
- **Probleem onderaannemer**: Elektro Van Damme niet verschenen deze week vanwege personeelstekort

---

## 5. KWALITEIT & VEILIGHEID

### Kwaliteitscontroles
- Wachtend op controle door Holcim voor vrijgave betonwerk fundering zone A (verwacht begin week 44)

### Veiligheid
- Incidenten: 0 arbeidsongevallen
- Acties: Waarschuwing gegeven aan bezoeker voor ontbrekende helmdracht

---

## 6. RISICO'S & AANDACHTSPUNTEN

**HOOG RISICO:**
- **Beschikbaarheid Elektro Van Damme**: Indien elektricien ook volgende week niet beschikbaar is, loopt de vertraging op naar 7-8 dagen. Dit heeft impact op het kritieke pad (fundering zone B kan niet starten zonder kelderinstallaties).
- **Mitigatie**: Contact opgenomen met Elektro Van Damme voor bevestiging beschikbaarheid week 44. Bij uitblijven wordt alternatieve elektricien ingeschakeld (offerte opgevraagd bij Elektrotechniek Desmet als backup).

**MEDIUM RISICO:**
- **Kwaliteitscontrole betonwerk**: Wachten op Holcim. Vertraging hierop heeft geen directe impact op kritiek pad.

**OPGELOST:**
- Verkeerde rioleringsbuizen: vervanging onderweg, geen planningsimpact.

---

## 7. PLANNING KOMENDE WEEK

Week 44 (30 oktober - 3 november 2025):
- Voltooiing rioleringswerken zone A (maandag-woensdag)
- Plaatsing elektrische leidingen kelder door Elektro Van Damme (dinsdag-donderdag)
- Kwaliteitscontrole betonwerk fundering zone A (verwacht maandag/dinsdag)
- Start fundering zone B (vrijdag, mits elektra kelder klaar is)

**Kritiek pad**: Elektrische leidingen kelder moeten af zijn vóór 3 november om vertraging te voorkomen.

---

## 8. BESLISSINGEN & ACTIEPUNTEN

| Actie | Verantwoordelijke | Deadline |
|-------|------------------|----------|
| Bevestiging beschikbaarheid elektricien week 44 | Elektro Van Damme | 30 okt 2025 |
| Plaatsing kelderinstallaties | Elektro Van Damme | 2 nov 2025 |
| Levering rioleringsbuizen Ø250mm | Leverancier | 30 okt 2025 |
| Backup-offerte elektricien (indien nodig) | Elektrotechniek Desmet | 31 okt 2025 |
| Kwaliteitscontrole betonwerk zone A | Holcim | 31 okt 2025 |
| Schriftelijke bevestiging wijziging raamkozijnen verd. 2 | Architect Callebaut | 3 nov 2025 |

---

**Opmerking**: Dit rapport is opgesteld conform de rapportageverplichting zoals overeengekomen in het bestek.
```

---

## 8. Meerwaarde van de Self Criticism & Revision Loops techniek

Deze techniek levert concrete verbeteringen op:

1. **Expliciete kwaliteitscontrole**: Door de AI te dwingen zichzelf te evalueren, worden tekortkomingen zichtbaar die anders gemist worden (bijv. de ontbrekende actie voor architect Callebaut).

2. **Diepere risico-analyse**: In de revisie worden niet alleen risico's benoemd, maar ook de impact en concrete mitigatie (backup-elektricien). Dit gebeurt niet automatisch in een baseline prompt.

3. **Betere volledigheid**: De zelfevaluatie dwingt om alle elementen uit de notities te verwerken. Informatie over het overleg met de architect verdwijnt niet meer.

4. **Professionelere toon**: De AI verbetert vage formuleringen ("situatie is beheersbaar") naar concrete voorwaarden en acties in de definitieve versie.

5. **Overdraagbaarheid**: Deze techniek werkt voor elk document dat aan een sjabloon of kwaliteitsnorm moet voldoen: offertes, veiligheidsplannen, nacalculaties, etc.

---

## 9. Variant / Transferoefening

**Alternatieve opdracht**: Pas dezelfde techniek toe op een **Dagrapportage Veiligheidscoördinator**.

Geef de AI ruwe notities van een werf met diverse veiligheidsincidenten (bijna-ongeval, materiaal niet conform, ontbrekende PBM's). Gebruik een sjabloon met verplichte velden volgens de Codex Welzijn op het Werk. Laat de AI eerst een rapport genereren, dan zelf controleren op:
- Zijn alle incidenten gedocumenteerd?
- Zijn correctieve acties concreet en toegewezen?
- Is de ernst van incidenten correct ingeschat?
- Zijn preventieve maatregelen voorgesteld?

Vervolgens laat je de AI het rapport herschrijven met alle verbeteringen.

---

## 10. De oefening is geslaagd als...

✅ **Structuur**: De definitieve output bevat drie duidelijke fases (genereer, evalueer, verbeter)

✅ **Zelfevaluatie**: De AI identificeert minimaal 4 concrete tekortkomingen in de eerste versie

✅ **Verbetering**: De definitieve versie lost alle geïdentificeerde problemen op en is merkbaar vollediger/professioneler dan de eerste versie

✅ **Volledigheid**: Alle informatie uit de notities is verwerkt in het definitieve rapport, inclusief details die vaak vergeten worden (overleg architect, backup-plannen)

✅ **Transfer**: De cursist kan het driestappenproces (genereer-evalueer-verbeter) toepassen op andere documenten zoals offertes, veiligheidsplannen of nacalculaties

---

## 11. Trainer Notes

**⏱ Geschatte duur**: 25-30 minuten
- 5 min: Uitleg techniek en casus
- 15 min: Zelfstandig uitvoeren door cursisten
- 5-10 min: Vergelijken baseline vs. verbeterde versie

**⚠ Valkuilen**:
- Cursisten laten alleen de prompt uitvoeren zonder de drie fases expliciet te benoemen → benadruk dat de AI de fases moet tonen
- Te algemene evaluatiecriteria → concrete checklist is essentieel
- Cursisten skippen fase 2 (evaluatie) omdat ze denken dat fase 3 genoeg is → leg uit dat expliciete zelfreflectie cruciaal is

**🤖 Geschikte tool**: 
- **Claude (Sonnet)**: Uitstekend voor gestructureerde zelfevaluatie
- **ChatGPT (GPT-4)**: Ook geschikt, soms minder kritisch op zichzelf
- **Gemini**: Minder aanbevolen, heeft moeite met expliciete fases

**🎯 Demowaarde** (3-minuten live demo):
Toon een split-screen:
- **Links**: Resultaat baseline prompt (1 keer genereren) → incompleet, mist risico's
- **Rechts**: Resultaat met zelfkritiek-loop → volledig, professioneel, met mitigaties

Benadruk visueel:
- In baseline ontbreekt de actie voor architect
- In verbeterde versie staat backup-plan voor elektricien
- Toon de zelfevaluatie-sectie waar de AI zelf tekortkomingen benoemde

**💡 Praktijktoepassing**:
Deze techniek is ideaal voor:
- Alle documenten die aan normen/sjablonen moeten voldoen (VCA, ISO, bestek)
- Offertes die compleet en zonder fouten moeten zijn
- Klantcommunicatie die professioneel moet overkomen
- Veiligheidsplannen waar volledigheid kritiek is

**🔄 Doorverwijzing**:
Na deze oefening kunnen cursisten verder met:
- Few-shot prompting (leer AI van 2-3 voorbeeldrapporteren)
- RAIL-techniek (voor strikte validatieregels)
- Chain-of-Thought (voor complexere redeneerstappen)
