# ACTIEPLAN GELUIDSOVERLAST - BETONWERKEN

**Werfnummer**: [invullen]
**Datum**: [invullen]
**Opgesteld door**: [invullen]
**Ter attentie van**: Dienst Bouwtoezicht Stad Leuven

---

## 1. ANALYSE SITUATIE

### Vastgestelde problemen
[Lijst de concrete problemen op]

### Oorzaken
[Wat waren de onderliggende oorzaken?]

### Toepasselijke regelgeving
[Welke regels zijn van toepassing en wat betekenen ze?]

---

## 2. VOORGESTELDE MAATREGELEN

### Maatregel 1: [Naam]
- **Type**: [Infrastructureel/Planning/Communicatie/etc.]
- **Doel**: [Wat lost dit op?]
- **Implementatie**: [Hoe en wanneer?]
- **Effect**: [Geschatte geluidreductie of andere impact]
- **Kostprijs**: [Bedrag]

[Herhaal voor elke maatregel]

---

## 3. GECOMBINEERDE IMPACT

**Totale verwachte geluidreductie**: [X dB(A)]
**Nieuw verwacht geluidsniveau**: [Y dB(A)] (norm: max 70 dB(A))
**Compliance met regelgeving**: [JA/NEE met toelichting]
**Impact op planning**: [X dagen vertraging/geen impact]
**Totale kostprijs**: [€X]

---

## 4. PLANNING RESTERENDE BETONWERKEN

| Datum | Werkzaamheden | Tijdstip | Verwacht geluidsniveau | Maatregelen actief |
|-------|---------------|----------|------------------------|-------------------|
| [datum] | [werk] | [tijd] | [dB] | [welke maatregelen] |

---

## 5. MONITORING & COMMUNICATIE

**Geluidmetingen**: [Hoe en wanneer wordt gemeten?]
**Communicatie omwonenden**: [Wanneer en hoe worden buren geïnformeerd?]
**Contactpersoon werf**: [Naam en GSM voor klachten]

---

## 6. ENGAGEMENT

Wij verbinden ons ertoe:
- [Concrete toezegging 1]
- [Concrete toezegging 2]
- [Concrete toezegging 3]

Bij nieuwe klachten: [Escalatieprocedure]

---

**Opgesteld op**: [datum]
**Goedkeuring werfleider**: [naam]
**Goedkeuring directie**: [naam]
```

