# Trainingsoefening: Step Back Prompting voor de Bouwsector

## 1. Techniek

**Step Back Prompting** - Eerst een stap terug zetten om bredere principes, context of achtergrondkennis te identificeren, voordat je de specifieke taak aanpakt. Dit helpt bij complexe problemen waar domeinkennis en regelgeving een rol spelen.

## 2. Casus

Een werfleider krijgt een klacht van de bouwtoezichter over geluidsoverlast tijdens betonwerken op een werf in een woonwijk. Hij moet een plan maken om het probleem op te lossen, maar moet daarbij rekening houden met Belgische regelgeving, praktische beperkingen en contractverplichtingen. Een oppervlakkige aanpak leidt tot oplossingen die niet uitvoerbaar of niet regelconform zijn.

## 3. Waarom een gewone prompt faalt

1. **Geen context over regelgeving** - Direct naar oplossingen springen zonder te begrijpen welke wettelijke normen van toepassing zijn (Vlarem, gemeentelijke politieverordeningen, arbeidswetgeving)
2. **Gemiste beperkingen** - Niet beseffen dat sommige "logische" oplossingen (zoals 's avonds werken) contractueel of wettelijk verboden kunnen zijn
3. **Onpraktische voorstellen** - Oplossingen die technisch niet haalbaar zijn voor specifieke werkzaamheden (je kan betonpompen niet "stil" maken)
4. **Geen prioritering** - Alle oplossingen lijken even belangrijk zonder te begrijpen wat de onderliggende oorzaken en kritieke succesfactoren zijn
5. **Gemiste stakeholders** - Vergeten dat er meerdere partijen betrokken zijn (omwonenden, gemeente, hoofdaannemer, onderaannemers)

## 4. Baseline Prompt

```text
Ik heb een klacht gekregen over geluidsoverlast op de werf. 
Maak een actieplan om dit op te lossen. Gebruik de informatie 
uit de bijlagen.

[Bijlagen: klacht, projectplanning, oplossingen, sjabloon]
```
