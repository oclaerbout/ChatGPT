# VEILIGHEIDSMELDING - VERWERKT

## Meldingsinformatie
- **Meldingnummer**: [Automatisch toekennen: VM-YYYYMMDD-XXX]
- **Ontvangstdatum**: [Datum uit melding]
- **Ontvangstijd**: [Tijd uit melding]
- **Melder**: [Naam + functie]

## Werfgegevens
- **Werfnummer**: [Uit melding]
- **Projectnaam**: [Opzoeken in werflijst]
- **Locatie**: [Uit melding]
- **Hoofdaannemer**: [Opzoeken in werflijst]

## Incidentbeschrijving
[Samenvatting incident uit originele melding - max 3 zinnen]

## Classificatie
- **Type incident**: [Categoriseren: Ongeval / Bijna-ongeval / Voorschriftovertreding / Materiaal / Observatie]
- **Urgentie**: [KRITIEK / HOOG / MEDIUM / LAAG]
- **Onderbouwing urgentie**: [Leg uit waarom deze classificatie obv urgentietabel]

## Toegewezen verantwoordelijke
- **Projectcoördinator**: [Naam uit werflijst]
- **Email**: [Email uit werflijst]
- **Telefoon**: [Telefoon uit werflijst]

## Voorgestelde acties
[Concrete acties obv urgentieniveau uit classificatietabel]

## Deadline eerste actie
[Bereken obv urgentieclassificatie]

---
**Verwerkt door**: AI Meldingensysteem
**Verwerkingsdatum**: [Vandaag]
**Status**: Toegewezen aan coördinator
