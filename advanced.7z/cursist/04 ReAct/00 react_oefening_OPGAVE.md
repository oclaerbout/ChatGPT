# ReAct Prompting Oefening - Bouwsector

## Techniek
**ReAct (Reasoning + Acting)** - Combinatie van redeneren en actie ondernemen. De AI denkt eerst na over wat nodig is, voert vervolgens een actie uit (zoals informatie opzoeken in een lijst), en gebruikt die informatie om verder te redeneren.

---

## Casus
Een werfleider ontvangt verschillende veiligheidsmeldingen van verschillende werven. Om deze correct te verwerken moet voor elke melding de juiste projectcoördinator worden gekoppeld, de urgentie worden bepaald obv het type incident, en een gestandaardiseerde actie worden voorgesteld. Alle benodigde informatie staat verspreid over verschillende lijsten (werflijst, coördinatorenlijst, urgentietabel).

---

## Waarom een gewone prompt faalt

1. **Geen systematisch opzoeken** - Baseline gaat gissen in plaats van actief te zoeken in de aangeleverde lijsten
2. **Informatie wordt niet gekoppeld** - Het verband tussen werfnummer → projectcoördinator wordt niet gelegd
3. **Geen prioritering** - Urgentie wordt niet bepaald obv objectieve criteria uit de urgentietabel
4. **Inconsistente output** - Elke melding wordt anders verwerkt zonder structuur
5. **Ontbrekende verificatie** - Er wordt niet gecontroleerd of de gekoppelde coordinator daadwerkelijk bij die werf hoort

## Baseline Prompt

```text
Verwerk deze 4 veiligheidsmeldingen. Gebruik de werflijst om de juiste 
coördinator te vinden en bepaal de urgentie. Maak voor elke melding een 
verwerkt rapport volgens het sjabloon.

[Bijlagen: meldingen, werflijst, urgentietabel, sjabloon]
```

---
