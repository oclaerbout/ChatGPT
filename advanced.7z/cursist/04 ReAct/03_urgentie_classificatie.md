# Urgentieclassificatie Veiligheidsincidenten

## KRITIEK (binnen 1 uur actie)
- Ongeval met gewonden
- Acuut gevaar voor personen
- Grote materiële schade met risico op escalatie
- Nutsleidingen geraakt (gas, elektriciteit, water)

**Acties:**
- Directe interventie coördinator
- Melding directie
- Extern deskundige inschakelen indien nodig

---

## HOOG (zelfde werkdag actie)
- Veiligheidsvoorschriften overtreden met potentieel gevaar
- Uitval essentiële apparatuur met veiligheidsimpact
- Structurele gebreken vastgesteld

**Acties:**
- Coördinator bezoekt werf zelfde dag
- Correctieve maatregelen opleggen
- Opvolging vastleggen

---

## MEDIUM (binnen 48 uur actie)
- Preventieve waarschuwingen
- Kleine materiële schade zonder gevaar
- Procedurefouten zonder direct risico

**Acties:**
- Coördinator plant bezoek binnen 2 dagen
- Schriftelijke opvolging
- Bespreking op werfvergadering

---

## LAAG (binnen 1 week opvolging)
- Administratieve meldingen
- Suggesties ter verbetering
- Observaties zonder acuut risico

**Acties:**
- Opname in wekelijks rapport
- Bespreking indien relevant
- Optioneel veldbezoek
