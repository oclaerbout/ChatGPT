# BESLISSINGSMATRIX LEVERANCIERSKEUZE

## Geëvalueerde Opties
- **Optie A**: [Leverancier naam]
- **Optie B**: [Leverancier naam]  
- **Optie C**: [Leverancier naam]

---

## Evaluatie per Optie

### OPTIE A: [Leverancier]

#### Voordelen
- [Voordeel 1]
- [Voordeel 2]
- [Voordeel 3]

#### Nadelen
- [Nadeel 1]
- [Nadeel 2]
- [Nadeel 3]

#### Risico's
- [Risico 1 + impact]
- [Risico 2 + impact]

#### Score per criterium (0-10)
| Criterium | Score | Toelichting |
|-----------|-------|-------------|
| Kostprijs | X/10 | [Berekening/redenering] |
| Levertijd & planning | X/10 | [Past in schema?] |
| Kwaliteit product | X/10 | [R-waarde, certificaten] |
| Leverbetrouwbaarheid | X/10 | [Ervaringen, referenties] |
| Risicoprofiel | X/10 | [Kans op problemen] |
| **TOTAAL** | **XX/50** | |

#### Totale projectkost (materiaal + risico)
- Materiaal: €X
- Risico vertraging (kans × boete): €X
- **Verwachte totaalkost**: €X

---

### OPTIE B: [Leverancier]
[Herhaal dezelfde structuur]

---

### OPTIE C: [Leverancier]
[Herhaal dezelfde structuur]

---

## Vergelijkende Analyse

### Ranking per criterium
1. **Beste prijs**: [Leverancier] (€X)
2. **Snelste levering**: [Leverancier] (X dagen)
3. **Hoogste kwaliteit**: [Leverancier] (R-waarde X)
4. **Meest betrouwbaar**: [Leverancier] (score X/10)
5. **Laagste risico**: [Leverancier] (verwacht €X extra)

### Deal-breakers & knock-out criteria
- [Welke opties vallen af en waarom?]

---

## EINDCONCLUSIE

### Aanbevolen keuze: [LEVERANCIER]

**Motivatie**:
[3-5 zinnen waarom deze optie de beste afweging is tussen alle criteria]

**Belangrijkste trade-offs**:
- We kiezen [aspect] boven [ander aspect] omdat [reden]
- We accepteren [nadeel] omdat [voordeel zwaarder weegt]

**Actie**:
- Bestellen bij: [Leverancier]
- Uiterste besteldatum: [Datum]
- Verantwoordelijke: [Naam werfleider]

**Fallback plan**:
Als deze leverancier niet kan leveren: [Tweede keuze + reden]
