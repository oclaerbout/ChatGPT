# Tree-of-Thought Oefening: Leverancierskeuze Bouwmaterialen

## 1. Techniek

**Tree-of-Thought (ToT)** - Multiple redeneringspaden parallel evalueren en vergelijken om tot de beste beslissing te komen. In plaats van lineair één oplossing te zoeken, ontwikkelt de AI meerdere scenario's ("takken") die systematisch worden beoordeeld op vooraf bepaalde criteria.

## 2. Casus

Een werfleider moet dringend 250m² isolatiemateriaal bestellen voor een renovatieproject in Leuven. Er zijn 3 leveranciers beschikbaar, elk met verschillende prijzen, levertijden en productspecificaties. De keuze moet gemaakt worden op basis van meerdere criteria: kostprijs, levertijd, kwaliteit, leverbetrouwbaarheid en totale projectimpact. Een verkeerde keuze kan leiden tot vertraging (schadevergoeding) of budgetoverschrijding.

## 3. Waarom een gewone prompt faalt

1. **Geen systematische afweging** - Baseline kiest vaak op basis van één criterium (meestal prijs) zonder andere factoren mee te wegen
2. **Tunnelvisie** - De AI stopt bij de eerste "redelijke" optie zonder alternatieven volledig te exploreren
3. **Geen risico-analyse** - Verborgen kosten (bv. werfstilstand door late levering) worden niet meegenomen
4. **Onduidelijke besluitvorming** - Het is niet traceerbaar waarom optie A beter is dan optie B
5. **Context wordt gemist** - Project-specifieke constraints (deadline, budget, kwaliteitseisen) worden niet systematisch geëvalueerd

## 4. Baseline Prompt

```text
Ik heb 3 offertes ontvangen voor isolatiemateriaal. 
Welke leverancier moet ik kiezen?

[Bijlagen: offerte-aanvraag, 3 offertes]
```
