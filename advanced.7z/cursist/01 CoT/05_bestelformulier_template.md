# BESTELFORMULIER MATERIAAL

**Bestelnummer**: [Automatisch]
**Datum**: [Vandaag]
**Aanvrager**: [Werfleider naam]
**Werfnummer**: [Bepalen uit context]
**Projectnaam**: [Uit systeem]
**Leveradres**: [Werflocatie]
**Gewenste levertijd**: [Uit aanvraag]

---

## BESTELDE ARTIKELEN

| Artikelcode | Omschrijving | Aantal | Eenheid | Prijs/eenheid | Subtotaal |
|-------------|--------------|--------|---------|---------------|-----------|
| [code] | [beschrijving] | [aantal] | [eenheid] | €[prijs] | €[totaal] |

---

## REDENERING BIJ BESTELLING

**Projecttype**: [Afgeleid uit werfgegevens]
**Werkfase**: [Uit systeem]
**Specifieke overwegingen**: [Waarom deze aantallen/materialen]

---

## TOTALEN

**Subtotaal materiaal**: €[bedrag]
**BTW 21%**: €[bedrag]
**TOTAAL**: €[bedrag]

---

## OPMERKINGEN & VERIFICATIE
[Eventuele aandachtspunten, aannames, of verificaties die nodig zijn]

**Status**: Klaar voor goedkeuring / Verificatie nodig
