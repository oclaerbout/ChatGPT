# Trainingsoefening: Beeldbewerking met AI voor de Bouwsector

## 1. Techniek: Beeldgeneratie & Beeldbewerking met Specifieke Prompting

**Kern:** Gebruik gedetailleerde, gestructureerde prompts om afbeeldingen te genereren en bewerken voor professionele bouwdoeleinden. Focus op precisie in beschrijving, context en technische specificaties.

**AI-tools:** ChatGPT (DALL-E 3 geïntegreerd) en Claude (via browser met beeldgeneratie)

## 2. Casus

Jouw bouwbedrijf "Veilig Bouwen NV" uit Mechelen organiseert een veiligheidscampagne op de werf voor het nieuwe ziekenhuisproject in Leuven. Je moet professionele visueel materiaal maken: een veiligheidsaffiche voor in de keet, een logo plaatsen op een bestaande werfafbeelding, en een realistische foto van jullie heras-afsluiting met bedrijfsspandoek. De grafisch ontwerper is ziek en het budget voor extern design is beperkt.

## 3. Waarom een gewone prompt faalt

Een baseline prompt zoals *"Maak een veiligheidsaffiche"* schiet tekort omdat:

1. **Gebrek aan specificiteit** - AI weet niet welke veiligheidsboodschap, in welke taal, voor welke doelgroep, met welke visuele stijl
2. **Geen merkidentiteit** - Kleuren, logo, huisstijl van het bedrijf worden niet meegenomen
3. **Verkeerde context** - Resultaat is vaak te algemeen, niet afgestemd op Belgische bouwsector (verkeerde taal, verkeerde normen, Amerikaanse context)
4. **Technische onbruikbaarheid** - Afmetingen, resolutie, tekstleesbaarheid worden niet gespecificeerd
5. **Onrealistische output bij bewerking** - Bij het plaatsen van logo's of spandoeken zonder duidelijke instructies krijg je onnatuurlijke resultaten

## 4. Training Assets

### Asset 1: Bedrijfsgegevens Veilig Bouwen NV
### Asset 2: Veiligheidsboodschappen
### Asset 3: Specificaties Visueel Materiaal
### Asset 4: Bestaande afbeelding (beschrijving voor simulatie)

## 5. Baseline Prompt (❌ Onvoldoende)

```text
Maak een veiligheidsaffiche voor een bouwwerf.
```

**Waarom dit faalt:**
- Geen taal gespecificeerd (krijg je Engels of Nederlands?)
- Geen specifieke veiligheidsboodschap
- Geen huisstijl of merkidentiteit
- Geen technische specificaties
- Geen context over doelgroep of sector

## 6. Prompts met Gestructureerde Beeldbewerking Techniek

### Prompt 1: Veiligheidsaffiche Genereren (ChatGPT/DALL-E 3)

```text
OPDRACHT: Genereer een professionele veiligheidsaffiche voor de bouwsector

CONTEXT:
- Bedrijf: Veilig Bouwen NV, Belgische bouwonderneming
- Project: Nieuwbouw ziekenhuis in Leuven
- Doelgroep: Bouwvakkers, Nederlands- en Franstalig

VISUELE SPECIFICATIES:
- Formaat: A2 poster (portrait oriëntatie)
- Kleurenschema: Oranje (#FF6B35) en Donkerblauw (#003D5C) als hoofdkleuren
- Stijl: Modern, strak, professioneel - geen cartoonachtig

VERPLICHTE INHOUD (tweetalig NL/FR):
Header (groot, opvallend):
- NL: "Val? Niet bij ons!"
- FR: "Chute? Pas chez nous!"

Subheader:
- NL: "Helm en veiligheidsharnas verplicht boven 2m"
- FR: "Casque et harnais obligatoires au-dessus de 2m"

Visuele elementen:
- Iconen: veiligheidshelm, harnas, waarschuwingsdriehoek
- Afbeelding: Silhouet van bouwvakker met correcte veiligheidsuitrusting
- Mockup van logo zone linksonder: rechthoek met tekst "VEILIG BOUWEN NV"

Footer:
- "Veiligheid is ieders verantwoordelijkheid"
- Emergency nummer: 0800/12.345

STIJLINSTRUCTIES:
- Gebruik contrasten voor leesbaarheid
- Grote, duidelijke lettertypen (sans-serif)
- Pictogrammen prominent aanwezig
- Professionele uitstraling (geen clipart)
- Vermijd rood (te agressief), focus op oranje als attentiekleur
```

### Prompt 2: Logo Plaatsen op Bestaande Foto (ChatGPT met beeldbewerking)

```text
OPDRACHT: Bewerk deze werfafbeelding door ons bedrijfslogo toe te voegen

CONTEXT VAN DE FOTO:
[Upload de foto: werf_leuven_overview.jpg]
Deze foto toont onze bouwwerf in Leuven met kraan, arbeiders en fundering.

BEWERKING:
Plaats een bedrijfslogo in de rechterbovenhoek met deze specificaties:

LOGO BESCHRIJVING:
- Vorm: Vierkant/rechthoekig logo
- Inhoud: Gestileerde helm in oranje kleur met tekst "VEILIG BOUWEN NV" in donkerblauwe letters eronder
- Tagline: "Bouwen met zekerheid" in kleine letters

TECHNISCHE EISEN:
- Positie: Rechterbovenhoek, met 5% marge vanaf de rand
- Grootte: Logo moet ongeveer 12-15% van de totale beeldbreedte beslaan
- Achtergrond: Semi-transparante witte achtergrond (opacity 80%) achter het logo voor leesbaarheid
- Stijl: Professioneel, clean design
- Het logo moet natuurlijk in de foto passen, alsof het er oorspronkelijk bijhoorde

KLEUREN LOGO:
- Helm icoon: Oranje (#FF6B35)
- Bedrijfsnaam: Donkerblauw (#003D5C)
- Achtergrond van logo: Wit met lichte transparantie

Behoud de rest van de foto ongewijzigd.
```

### Prompt 3: Heras Afsluiting met Spandoek (DALL-E / Claude generatie)

```text
OPDRACHT: Genereer een realistische foto van een bouwwerfafsluiting met bedrijfsspandoek

SCENE BESCHRIJVING:
Maak een foto-realistische afbeelding van een bouwwerf afsluiting op een Belgische locatie.

BASISSCENE:
- Locatie: Stedelijke omgeving, Belgische context (Vlaamse architectuur op achtergrond)
- Weer: Bewolkt maar droog, typisch Belgisch weer
- Tijdstip: Ochtend/middag, natuurlijk daglicht
- Perspectief: Frontaal zicht, ooghoogte, op 3-4 meter afstand

HERAS HEKKEN:
- Type: Standaard bouwplaats heras hekken (metalen mobile fencing)
- Aantal: Minimaal 3 panelen zichtbaar, naast elkaar geplaatst
- Kleur: Gegalvaniseerd staal (zilvergrijs)
- Staat: Professioneel geplaatst, stabiel, met voetplaten

BEDRIJFSSPANDOEK (HOOFDELEMENT):
- Positie: Op het centrale heras paneel, professioneel bevestigd
- Afmetingen: Standaard spandoek (ongeveer 3.5m breed x 2m hoog)
- Bevestiging: Zichtbaar strak gespannen met binders/kabelbinders, geen rimpels

SPANDOEK DESIGN:
Achtergrond: Feloranje (#FF6B35) - volledig dekkend
Linkerzijde (30%): 
  - Logo: Gestileerde witte helm icoon
  - Tekst: "uptune" in witte hoofdletters

Rechterzijde (70%):
  - Grote tekst: "www.uptune.ai"
  - Contactinfo: "015/12.34.56"
  - Tagline: "Bouwen met zekerheid"
  - Alle tekst in wit, sans-serif lettertype, dik en leesbaar

REALISME:
- Spandoek moet er professioneel uitzien, niet perfect strak (lichte golving is natureel)
- Lichte schaduwen van hekken op de grond
- Spandoek moet fysiek correct aan hekken bevestigd lijken
- Geen perfectie: subtiele tekenen van buitengebruik (lichte kreukels OK)

OMGEVING:
- Achtergrond: Vaag zichtbare bouwwerf (kraan, container)
- Voorgrond: Stoeptegel of asfalt (Belgische straatcontext)
- Optioneel: Voorbijganger in de verte voor schaal
- Geen andere merknamen of logo's zichtbaar

FOTOSTIJL:
- Realistische fotografie, geen render-look
- Natuurlijke kleuren en belichting
- Scherpe focus op spandoek, lichte bokeh op achtergrond
- Professionele kwaliteit, bruikbaar voor website/portfolio
```

