# MEERWERK OFFERTE

**Project**: [Projectnaam]
**Werfnummer**: [Nummer]
**Datum offerte**: [Datum]
**Geldig tot**: [Datum + 14 dagen]

---

## OMSCHRIJVING MEERWERK

[Gedetailleerde beschrijving wat uitgevoerd wordt]

---

## MATERIAAL & ARBEID

| Post | Omschrijving | Aantal | Eenheid | Prijs/Eenheid | Subtotaal |
|------|-------------|--------|---------|---------------|-----------|
| [Materiaal items] | | | | | |
| [Arbeid items] | | | | | |

**Subtotaal materiaal**: €[bedrag]
**Subtotaal arbeid**: €[bedrag] ([totaal uren] uren × €55/uur)

---

## TOTAAL

**Totaal excl. BTW**: €[bedrag]
**BTW 21%**: €[bedrag]
**TOTAAL INCL. BTW**: €[bedrag]

---

## AANNAMES & VOORWAARDEN

[Lijst met aannames en voorwaarden]

---

## RISICO-INSCHATTING

**Betrouwbaarheid**: [Laag / Middel / Hoog]
**Mogelijke meerkosten**: [Verklaring indien risico's]

---

**Opgemaakt door**: [Naam]
**Functie**: Werfleider
```

